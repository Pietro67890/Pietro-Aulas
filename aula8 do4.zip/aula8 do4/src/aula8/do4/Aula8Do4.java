/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula8.do4;

/**
 *
 * @author Pietro.rsousa
 */
public class Aula8Do4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here[
       public class JavaApplication42 {
        public static void frase(){
            System.out.println("imprimindo usando função");
            
        }
        public static void frase2();
    }
    
}
